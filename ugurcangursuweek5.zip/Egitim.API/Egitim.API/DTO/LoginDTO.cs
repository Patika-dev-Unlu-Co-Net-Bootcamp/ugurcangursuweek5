﻿
namespace Egitim.API.DTO
{
    public class LoginDTO
    {
        public string username { get; set; }
        public string pass { get; set; }
    }
}
