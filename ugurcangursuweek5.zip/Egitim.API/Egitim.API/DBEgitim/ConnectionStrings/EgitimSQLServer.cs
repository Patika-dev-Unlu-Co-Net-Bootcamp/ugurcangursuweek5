﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egitim.API.DBEgitim.ConnectionStrings
{
    public class EgitimSQLServer : Base
    {
    }
}
