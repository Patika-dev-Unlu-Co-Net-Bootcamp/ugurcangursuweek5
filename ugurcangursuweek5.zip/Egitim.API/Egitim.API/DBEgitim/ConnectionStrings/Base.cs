﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egitim.API.DBEgitim.ConnectionStrings
{
    public class Base
    {
        public static string Title { get; set; }
        public static string Text { get; set; }
    }
}
