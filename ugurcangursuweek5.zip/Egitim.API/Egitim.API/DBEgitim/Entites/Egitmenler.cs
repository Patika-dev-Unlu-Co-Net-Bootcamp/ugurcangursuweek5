﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egitim.API.DBEgitim.Entites
{
    public class Egitmenler
    {
        public int Id { get; set; }
        public string AdiSoyadi { get; set; }
        public string Brans { get; set; }
        public string TC { get; set; }
        public string Telno { get; set; }
    }
}
