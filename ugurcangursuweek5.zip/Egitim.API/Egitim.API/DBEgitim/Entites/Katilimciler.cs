﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egitim.API.DBEgitim.Entites
{
    public class Katilimciler
    {
        public int Id { get; set; }
        public string AdiSoyad { get; set; }
        public string TC { get; set; }
        public string TelNo { get; set; }
    }
}
